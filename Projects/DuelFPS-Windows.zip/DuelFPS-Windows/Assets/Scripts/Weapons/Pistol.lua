return {
    id="pistol", shortName="MAKO", displayName="MAKO P12 / SIDEARM",
    viewmodelPrefab="Assets/Prefabs/PistolViewmodel.prefab",
    fireSound="Assets/Audio/Breakbulk/sidearm.wav",
    magSize=12, startingReserve=48, practiceReserve=999,
    reloadTime=1.25, fireInterval=0.22, damage=25, range=100,
    automatic=false, pellets=1,
    hipFov=90, adsFov=72, hipSide=0.27, adsSide=0,
    hipForward=0.56, adsForward=0.63, hipDown=-0.12, adsDown=-0.012,
    cameraKick=0.010, viewKick=0.045, kickRecovery=6,
    recoilRiseSpeed=12, recoilReturnSpeed=7,
    muzzleLocalDistance=0.585, muzzleLocalY=0.015
}
