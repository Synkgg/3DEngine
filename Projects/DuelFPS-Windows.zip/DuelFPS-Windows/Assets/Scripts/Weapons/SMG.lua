return {
    id="smg", shortName="VECTOR", displayName="VECTOR K9 / SMG",
    viewmodelPrefab="Assets/Prefabs/SMGViewmodel.prefab",
    fireSound="Assets/Audio/Breakbulk/carbine.wav",
    magSize=36, startingReserve=144, practiceReserve=999,
    reloadTime=1.40, fireInterval=0.072, damage=15, range=90,
    automatic=true, pellets=1,
    hipFov=90, adsFov=72, hipSide=0.31, adsSide=0,
    hipForward=0.57, adsForward=0.66, hipDown=-0.12, adsDown=-0.012,
    cameraKick=0.012, viewKick=0.045, kickRecovery=9.5,
    muzzleLocalDistance=0.87, muzzleLocalY=0.005
}
